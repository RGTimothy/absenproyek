<?php

namespace api\modules\v1\controllers;

use yii;
use yii\rest\ActiveController;

class CompanyProjectController extends ActiveController
{
	// public $modelClass = 'api\modules\v1\models\Company';
}
