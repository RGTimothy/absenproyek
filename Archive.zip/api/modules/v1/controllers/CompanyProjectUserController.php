<?php

namespace api\modules\v1\controllers;

use yii;
use yii\rest\ActiveController;

class CompanyProjectUserController extends ActiveController
{
	// public $modelClass = 'api\modules\v1\models\Company';
}
